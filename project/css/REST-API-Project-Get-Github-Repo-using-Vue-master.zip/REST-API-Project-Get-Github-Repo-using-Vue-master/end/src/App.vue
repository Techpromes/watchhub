<template>
  <div id="app">
    <Repository />
  </div>
</template>

<script>
import Repository from './components/Repository'

export default {
  name: 'App',
  components: {
    Repository
  }
}
</script>

