module.exports = {
  publicPath: process.env.NODE_ENV === 'production'
    ? '/demo/rest/get-github-repo-using-vue/'
    : '/'
}